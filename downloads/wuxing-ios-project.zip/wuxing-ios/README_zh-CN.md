# iOS 工程使用与收费发布

当前工程已通过 GitHub Mac 环境的 Xcode iOS 模拟器目标编译，未签名、未进行真机验收。需要 Mac、支持当前 App Store 提交要求的 Xcode、iPhone/iPad 和 Apple Developer 会员。不要把 Apple 密码、证书私钥或访问令牌发到聊天里。

1. 将整个 `ios` 文件夹复制到 Mac，双击 `Wuxing.xcodeproj`。请保留同级 `web` 文件夹。
2. 选择 Wuxing target → Signing & Capabilities，选择自己的 Team，勾选自动签名。将 `com.wuxing.chronicles` 换成自己的唯一 Bundle Identifier。当前工程没有配置任何开发者 Team。
3. 先选 iOS 模拟器运行，再连接真机运行。检查五角色技能、骑宠、六装备位、旋转与安全区域、前后台暂停、导入导出、断网运行、关闭重开后的存档。iOS 原生桥将进度备份到 app 自己的 UserDefaults，不使用云服务。
4. 选择 Any iOS Device → Product → Archive。或者执行：`DEVELOPMENT_TEAM=你的TeamID PRODUCT_BUNDLE_IDENTIFIER=你的唯一标识 sh archive.sh`。成功后在 Organizer 里 Validate，再上传 App Store Connect。
5. 在 App Store Connect 创建同 Bundle ID 的 App，填写名称、语言、分类、年龄分级、内容权利、隐私和支持链接。隐私清单已经声明 app 自己的 UserDefaults 用途（CA92.1）；如新增 SDK、联网或数据采集必须重新核查。
6. 先用 TestFlight 完成真机和多人设备测试。截图必须来自最终 iPhone/iPad 实际界面，不能把电脑截图当成手机截图上传。当前交付中没有已验收的 iOS 截图。
7. 选择「付费下载」模式：在 App Store Connect 完成付费协议、银行及税务信息，之后才能设置价格和销售地区。这里不替你接受协议、提交银行税务资料或决定售价。
8. 提交审核。该工程包含完整离线游戏及原生存档文件交互，但 WebView 技术本身不能保证满足所有审核要求。正式提交前根据审核指南检查最低功能、完整性、知识产权、元数据与目标地区的游戏发行要求。

可填写的产品资料：
- 名称：五行纪：行者之约（需查重）
- 副标题：五行小队与灵兽的远征
- 描述：在五座灵脉之间展开原创奇幻冒险。招募金、木、水、火、土五位战士，培养力量、智力与敏捷，组合十五种技能，挑战拥有多阶段攻击的守护者。收集六部位装备，驯服恐龙、白虎、玄武、青龙与朱雀，完成场景支线。支持离线单人游戏，队友由电脑操控。
- 关键词：五行,角色扮演,离线,冒险,灵兽,升级,动作
- 支持链接：公开仓库 Issues 或发行方自己的支持页，提交前验证能访问且有人处理。
- 隐私链接：公开网站的 privacy.html，提交前核对实际数据行为与发行方信息。

尚需发行方完成：开发者身份与唯一标识、法律主体和联系方式、素材权利复核、真机验收、最终截图、内容分级、售价、协议税务及审核提交。

官方参考：
- [Apple 审核指南](https://developer.apple.com/app-store/review/guidelines/)
- [付费协议](https://developer.apple.com/help/app-store-connect/manage-agreements/sign-and-update-agreements/)
- [设置售价](https://developer.apple.com/help/app-store-connect/manage-app-pricing/set-a-price/)
- [归档和分发](https://developer.apple.com/documentation/xcode/distributing-your-app-for-beta-testing-and-releases)
- [UserDefaults 隐私声明](https://developer.apple.com/documentation/foundation/userdefaults)
