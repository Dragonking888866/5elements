#!/bin/sh
set -eu
cd "$(dirname "$0")"
: "${DEVELOPMENT_TEAM:?Set DEVELOPMENT_TEAM to your Apple team ID}"
: "${PRODUCT_BUNDLE_IDENTIFIER:?Set your unique PRODUCT_BUNDLE_IDENTIFIER}"
xcodebuild -project Wuxing.xcodeproj -scheme Wuxing -configuration Release -destination 'generic/platform=iOS' -archivePath build/Wuxing.xcarchive DEVELOPMENT_TEAM="$DEVELOPMENT_TEAM" PRODUCT_BUNDLE_IDENTIFIER="$PRODUCT_BUNDLE_IDENTIFIER" -allowProvisioningUpdates archive
echo 'Archive created. Open Xcode Organizer to validate and upload with your App Store Connect account.'
