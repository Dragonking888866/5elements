import UIKit
import WebKit
import UniformTypeIdentifiers

/// Bundled offline game. No analytics, advertising SDKs or remote game code.
final class GameViewController: UIViewController, WKScriptMessageHandler, WKNavigationDelegate, UIDocumentPickerDelegate {
    private var webView: WKWebView!
    private let saveKey = "wuxing-chronicles-v5"
    private var pendingExport: URL?

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(red: 0.06, green: 0.14, blue: 0.16, alpha: 1)
        let configuration = WKWebViewConfiguration()
        configuration.websiteDataStore = .default()
        configuration.allowsInlineMediaPlayback = true
        configuration.userContentController.add(self, name: "game")
        if let saved = (UserDefaults.standard.string(forKey: saveKey) ?? UserDefaults.standard.string(forKey: "wuxing-chronicles-v4")), let data = try? JSONSerialization.data(withJSONObject: [saved]), let array = String(data: data, encoding: .utf8) {
            let code = "try { if (!localStorage.getItem('wuxing-chronicles-v5')) localStorage.setItem('wuxing-chronicles-v5', \(array)[0]); } catch (_) {}"
            configuration.userContentController.addUserScript(WKUserScript(source: code, injectionTime: .atDocumentStart, forMainFrameOnly: true))
        }
        let tools = """
        document.addEventListener('DOMContentLoaded',function(){
          var b=document.createElement('button');b.className='ghost';b.textContent='导入存档';
          b.onclick=function(){window.webkit.messageHandlers.game.postMessage({action:'import'});};
          document.querySelector('.head-right').appendChild(b);var m=b.cloneNode(true);m.onclick=b.onclick;document.querySelector('.mobile-dock').appendChild(m);
        });
        """
        configuration.userContentController.addUserScript(WKUserScript(source: tools, injectionTime: .atDocumentStart, forMainFrameOnly: true))
        webView = WKWebView(frame: .zero, configuration: configuration)
        webView.navigationDelegate = self
        webView.isOpaque = false
        webView.backgroundColor = view.backgroundColor
        webView.scrollView.bounces = false
        webView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(webView)
        NSLayoutConstraint.activate([
            webView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor),
            webView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor),
            webView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            webView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor)
        ])
        guard let folder = Bundle.main.resourceURL?.appendingPathComponent("web"), FileManager.default.fileExists(atPath: folder.appendingPathComponent("index.html").path) else {
            showError("缺少游戏资源，请将 web 文件夹作为 folder reference 加入工程。")
            return
        }
        webView.loadFileURL(folder.appendingPathComponent("index.html"), allowingReadAccessTo: folder)
        NotificationCenter.default.addObserver(self, selector: #selector(backgrounded), name: UIApplication.willResignActiveNotification, object: nil)
    }
    override var prefersStatusBarHidden: Bool { true }
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask { .landscape }
    override var prefersHomeIndicatorAutoHidden: Bool { true }
    @objc private func backgrounded() {
        webView.evaluateJavaScript("if(typeof saveGame==='function'){saveGame(false);if(S&&!menu)pausePanel();} clearStick();", completionHandler: nil)
    }
    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        guard message.frameInfo.isMainFrame, message.frameInfo.request.url?.isFileURL == true, let body = message.body as? [String: Any], let action = body["action"] as? String else { return }
        switch action {
        case "persist":
            if let json = body["json"] as? String, json.utf8.count < 2_000_000, let data = json.data(using: .utf8), (try? JSONSerialization.jsonObject(with: data)) is [String: Any] {
                UserDefaults.standard.set(json, forKey: saveKey)
            }
        case "export":
            guard presentedViewController == nil, let json = body["json"] as? String, json.utf8.count < 2_000_000 else { return }
            let file = FileManager.default.temporaryDirectory.appendingPathComponent("wuxing-save-\(UUID().uuidString).json")
            do {
                try json.write(to: file, atomically: true, encoding: .utf8)
                pendingExport = file
                let picker = UIDocumentPickerViewController(forExporting: [file], asCopy: true)
                picker.delegate = self
                present(picker, animated: true)
            } catch { showError("无法导出存档：\(error.localizedDescription)") }
        case "import":
            guard presentedViewController == nil else { return }
            let picker = UIDocumentPickerViewController(forOpeningContentTypes: [.json, .plainText], asCopy: true)
            picker.delegate = self
            picker.allowsMultipleSelection = false
            present(picker, animated: true)
        default: break
        }
    }
    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        if pendingExport != nil { cleanExport(); return }
        guard let url = urls.first else { return }
        let access = url.startAccessingSecurityScopedResource()
        defer { if access { url.stopAccessingSecurityScopedResource() } }
        do {
            let size = try url.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? 0
            guard size <= 2_000_000 else { showError("存档过大。"); return }
            let data = try Data(contentsOf: url)
            guard let json = String(data: data, encoding: .utf8), (try JSONSerialization.jsonObject(with: data)) is [String: Any] else { showError("请选择 JSON 存档。"); return }
            let alert = UIAlertController(title: "导入存档？", message: "当前进度将被替换，并保留一份本机备份。", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "取消", style: .cancel))
            alert.addAction(UIAlertAction(title: "导入", style: .default) { [weak self] _ in
                guard let self = self, let encoded = try? JSONSerialization.data(withJSONObject: [json]), let argument = String(data: encoded, encoding: .utf8) else { return }
                if let old = UserDefaults.standard.string(forKey: self.saveKey) { UserDefaults.standard.set(old, forKey: self.saveKey + ".backup") }
                self.webView.evaluateJavaScript("window.receiveNativeSave(\(argument)[0]);", completionHandler: nil)
            })
            present(alert, animated: true)
        } catch { showError("无法读取存档：\(error.localizedDescription)") }
    }
    func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) { cleanExport() }
    private func cleanExport() { if let file = pendingExport { try? FileManager.default.removeItem(at: file) }; pendingExport = nil }
    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let url = navigationAction.request.url else { decisionHandler(.cancel); return }
        if url.isFileURL, let root = Bundle.main.resourceURL?.appendingPathComponent("web").standardizedFileURL.path, url.standardizedFileURL.path.hasPrefix(root + "/") {
            decisionHandler(.allow)
        } else { decisionHandler(.cancel) }
    }
    private func showError(_ text: String) {
        let alert = UIAlertController(title: "五行纪", message: text, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "确定", style: .default))
        present(alert, animated: true)
    }
}

